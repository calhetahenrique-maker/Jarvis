# JARVIS Business v0.7.0

Android app (Kotlin + Jetpack Compose).

## Business updates
- Multi-item orders with saved unit prices.
- 16% VAT calculation.
- Configurable warehouse email, prefilled with jorge.g.b.pimentel@bensaude.pt.
- Order email draft with customer, item lines, quantities, subtotal, VAT and total.
- Explicit confirmation before opening the email app; user reviews and sends manually.

## Build
Run `gradle assembleDebug` from this project directory using JDK 17 and Android SDK platform 35.
