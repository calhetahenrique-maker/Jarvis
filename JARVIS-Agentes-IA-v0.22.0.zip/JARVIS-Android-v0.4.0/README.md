# JARVIS Business v0.22.0

Aplicação Android Kotlin + Jetpack Compose, com base de dados SQLite local.

## Novidades v0.22.0 — Agentes e IA online
- Página de Agentes com JARVIS Master, Agente Comercial, Agente de Encomendas, Agente de Produtos e Agente de Assistência.
- Chat online compatível com APIs no formato OpenAI Chat Completions.
- Definições para URL do serviço, nome do modelo e chave API. A chave é guardada em SharedPreferences privadas da aplicação; não está incluída no código nem no ZIP.
- Entrada por voz com reconhecimento em português de Portugal e respostas faladas através da síntese de voz Android.
- A aplicação e os módulos locais continuam utilizáveis sem Internet; apenas as respostas do modelo online exigem ligação.

## Configuração da IA
1. Abrir **Agentes** ou **JARVIS**.
2. Abrir as definições (⚙).
3. Introduzir a URL compatível com Chat Completions, o modelo e a chave API do fornecedor escolhido.
4. Guardar e enviar uma mensagem.

O endpoint predefinido é `https://api.openai.com/v1/chat/completions` e o modelo sugerido é `gpt-4o-mini`. A utilização pode ter custos cobrados pelo fornecedor. Não existe uma chave API incluída.

## Agentes
Os agentes especializados aplicam instruções próprias ao diálogo. Nesta versão, respondem e orientam o utilizador; ainda não executam operações de escrita na base de dados nem enviam encomendas por iniciativa própria. Essas ações devem ser integradas numa fase posterior com confirmação explícita do utilizador.

## Funcionalidades preservadas
- Clientes, produtos, fotografias, referências e formatos.
- Encomendas por seleção de cliente e catálogo de fotografias, com formatos e preços independentes.
- PDF e partilha por email.
- Atividade comercial, relatórios e cópias de segurança.
- IVA predefinido de 16%.

Application ID: `com.example.aios`.
Version code: 26.

## Compilação
Usar o workflow do repositório GitHub. Para atualização sem perder os dados locais, manter o mesmo `applicationId`, uma `versionCode` superior e a mesma chave de assinatura da instalação existente. Não desinstalar a versão anterior para resolver conflitos de assinatura.

A compilação deve ser validada no GitHub Actions antes da instalação.
