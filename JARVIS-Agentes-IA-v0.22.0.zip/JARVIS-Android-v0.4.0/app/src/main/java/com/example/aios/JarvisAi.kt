package com.example.aios

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** OpenAI-compatible online chat service. Credentials are stored only in app-private preferences. */
internal data class AiConfig(val endpoint: String, val model: String, val apiKey: String)

internal object JarvisAi {
    fun loadConfig(context: Context): AiConfig {
        val p = context.getSharedPreferences("jarvis_ai", Context.MODE_PRIVATE)
        return AiConfig(
            p.getString("endpoint", "https://api.openai.com/v1/chat/completions") ?: "",
            p.getString("model", "gpt-4o-mini") ?: "gpt-4o-mini",
            p.getString("api_key", "") ?: ""
        )
    }

    fun saveConfig(context: Context, endpoint: String, model: String, key: String) {
        context.getSharedPreferences("jarvis_ai", Context.MODE_PRIVATE).edit()
            .putString("endpoint", endpoint.trim())
            .putString("model", model.trim())
            .putString("api_key", key.trim()).apply()
    }

    fun reply(config: AiConfig, agent: String, prompt: String, callback: (String) -> Unit) {
        Thread {
            val answer = try {
                require(config.endpoint.startsWith("https://")) { "O endereço do serviço tem de começar por https://" }
                require(config.model.isNotBlank()) { "Indica o modelo de IA nas definições." }
                require(config.apiKey.isNotBlank()) { "Falta configurar a chave API nas definições da IA." }
                val system = "És o JARVIS, assistente de uma aplicação Android de gestão comercial. Responde sempre em português de Portugal, de forma clara e prática. Agente ativo: $agent. Não inventes dados de clientes, produtos, encomendas, preços ou tarefas. Se não tiveres acesso a um dado da aplicação, explica-o e pede a informação necessária. Não afirmes que executaste ações na aplicação; apenas orienta o utilizador."
                val messages = JSONArray()
                    .put(JSONObject().put("role", "system").put("content", system))
                    .put(JSONObject().put("role", "user").put("content", prompt))
                val body = JSONObject().put("model", config.model).put("messages", messages).put("temperature", 0.4)
                val conn = (URL(config.endpoint).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"; connectTimeout = 20000; readTimeout = 45000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json")
                    setRequestProperty("Authorization", "Bearer ${config.apiKey}")
                }
                conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val raw = stream.bufferedReader().use { it.readText() }
                conn.disconnect()
                if (code !in 200..299) {
                    val detail = try { JSONObject(raw).optJSONObject("error")?.optString("message") } catch (_: Exception) { null }
                    "Erro do serviço de IA ($code): ${detail?.takeIf { it.isNotBlank() } ?: raw.take(300)}"
                } else {
                    JSONObject(raw).optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")?.optString("content")
                        ?.takeIf { it.isNotBlank() } ?: "O serviço respondeu sem texto."
                }
            } catch (e: Exception) {
                "Não foi possível obter resposta da IA: ${e.message ?: "erro de ligação"}"
            }
            callback(answer)
        }.start()
    }
}
