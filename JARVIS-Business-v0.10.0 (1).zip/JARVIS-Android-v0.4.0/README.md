# JARVIS Business v0.10.0

Android app built with Kotlin, Jetpack Compose and local SQLite.

## Novidades
- Exportar encomendas individuais em PDF para guardar ou partilhar.
- Exportar cópia de segurança JSON de clientes, produtos e encomendas.
- Restaurar cópia JSON (substitui os registos atuais).
- IVA predefinido de 16%.
- Email do armazém predefinido: jorge.g.b.pimentel@bensaude.pt.

## Build
Colocar `JARVIS-Business-v0.10.0.zip` na raiz do repositório GitHub e executar o workflow `Build JARVIS APK`. O artefacto será `JARVIS-Business-v0.10.0-APK`.

## Assinatura Android
A compilação debug do GitHub Actions usa uma chave debug gerada no runner. Para atualizações Android sem desinstalar, todas as versões têm de ser assinadas com a mesma chave privada. Não remover a app instalada antes de confirmar a compatibilidade da assinatura.
