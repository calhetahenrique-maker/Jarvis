# JARVIS Android v0.4.0

Projeto Android nativo em Kotlin + Jetpack Compose, com tema escuro e base de dados SQLite local.

## Abrir
1. Extrair o ZIP.
2. Abrir a pasta `JARVIS-Android-v0.4.0` no Android Studio.
3. Aguardar a sincronização Gradle.
4. Executar num emulador ou telemóvel Android.

Requisitos: Android Studio recente, JDK 17 e Android SDK 35. Identificador: `com.example.aios`.

## Funcionalidades
- Dashboard com contadores de clientes, produtos e encomendas.
- Registo e consulta de clientes.
- Catálogo simples com nome, referência e preço.
- Registo de encomendas com cliente, produto, quantidade e observações.
- Eliminação de registos.
- Persistência local SQLite: os dados mantêm-se ao fechar e reabrir a aplicação.

## Ainda por desenvolver
- Edição de registos, fotografias dos produtos, pesquisa e filtros.
- Exportação e envio de encomendas por Outlook/email.
- IA real e agentes ativos.
- Sincronização cloud e cópia de segurança.

Esta entrega é código-fonte, não um APK assinado. Os dados ficam neste dispositivo; desinstalar a app pode apagá-los.
