# JARVIS Business v0.7.1

Correção da base de dados: cria as tabelas de encomendas múltiplas tanto em instalações novas como em atualizações existentes. Mantém os dados locais e incrementa a versão Android para permitir a migração automática.

Build APK via GitHub Actions.
