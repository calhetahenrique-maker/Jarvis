package com.example.aios

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class Client(val id: Long, val name: String, val company: String, val phone: String, val email: String)
data class Product(val id: Long, val name: String, val code: String, val price: Double)
data class OrderRow(val id: Long, val client: String, val product: String, val quantity: Int, val notes: String, val unitPrice: Double, val status: String)

data class OrderItem(val product: String, val quantity: Int, val unitPrice: Double)
data class MultiOrder(val id: Long, val client: String, val notes: String, val status: String, val items: List<OrderItem>)

class LocalDatabase(context: Context) : SQLiteOpenHelper(context, "jarvis_local.db", null, 3) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE clients (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, company TEXT NOT NULL DEFAULT '', phone TEXT NOT NULL DEFAULT '', email TEXT NOT NULL DEFAULT '')")
        db.execSQL("CREATE TABLE products (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, code TEXT NOT NULL DEFAULT '', price REAL NOT NULL DEFAULT 0)")
        db.execSQL("CREATE TABLE orders_local (id INTEGER PRIMARY KEY AUTOINCREMENT, client TEXT NOT NULL, product TEXT NOT NULL, quantity INTEGER NOT NULL, notes TEXT NOT NULL DEFAULT '', unit_price REAL NOT NULL DEFAULT 0, status TEXT NOT NULL DEFAULT 'Pendente')")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE orders_local ADD COLUMN unit_price REAL NOT NULL DEFAULT 0")
            db.execSQL("ALTER TABLE orders_local ADD COLUMN status TEXT NOT NULL DEFAULT 'Pendente'")
        }
        if (oldVersion < 3) {
            db.execSQL("CREATE TABLE order_headers (id INTEGER PRIMARY KEY AUTOINCREMENT, client TEXT NOT NULL, notes TEXT NOT NULL DEFAULT '', status TEXT NOT NULL DEFAULT 'Pendente')")
            db.execSQL("CREATE TABLE order_items (id INTEGER PRIMARY KEY AUTOINCREMENT, order_id INTEGER NOT NULL, product TEXT NOT NULL, quantity INTEGER NOT NULL, unit_price REAL NOT NULL, FOREIGN KEY(order_id) REFERENCES order_headers(id) ON DELETE CASCADE)")
            db.rawQuery("SELECT client, product, quantity, notes, unit_price FROM orders_local ORDER BY id", null).use { c ->
                while (c.moveToNext()) {
                    val values = ContentValues().apply { put("client", c.getString(0)); put("notes", c.getString(3)); put("status", "Pendente") }
                    val id = db.insert("order_headers", null, values)
                    val item = ContentValues().apply { put("order_id", id); put("product", c.getString(1)); put("quantity", c.getInt(2)); put("unit_price", c.getDouble(4)) }
                    db.insert("order_items", null, item)
                }
            }
        }
    }

    fun addClient(name: String, company: String, phone: String, email: String) {
        writableDatabase.insert("clients", null, ContentValues().apply {
            put("name", name); put("company", company); put("phone", phone); put("email", email)
        })
    }
    fun addProduct(name: String, code: String, price: Double) {
        writableDatabase.insert("products", null, ContentValues().apply {
            put("name", name); put("code", code); put("price", price)
        })
    }
    fun addOrder(client: String, product: String, quantity: Int, notes: String, unitPrice: Double) {
        writableDatabase.insert("orders_local", null, ContentValues().apply {
            put("client", client); put("product", product); put("quantity", quantity); put("notes", notes); put("unit_price", unitPrice); put("status", "Pendente")
        })
    }
    fun clients(): List<Client> = readableDatabase.rawQuery("SELECT id,name,company,phone,email FROM clients ORDER BY name", null).use { c ->
        buildList { while (c.moveToNext()) add(Client(c.getLong(0), c.getString(1), c.getString(2), c.getString(3), c.getString(4))) }
    }
    fun products(): List<Product> = readableDatabase.rawQuery("SELECT id,name,code,price FROM products ORDER BY name", null).use { c ->
        buildList { while (c.moveToNext()) add(Product(c.getLong(0), c.getString(1), c.getString(2), c.getDouble(3))) }
    }
    fun orders(): List<OrderRow> = readableDatabase.rawQuery("SELECT id,client,product,quantity,notes,unit_price,status FROM orders_local ORDER BY id DESC", null).use { c ->
        buildList { while (c.moveToNext()) add(OrderRow(c.getLong(0), c.getString(1), c.getString(2), c.getInt(3), c.getString(4), c.getDouble(5), c.getString(6))) }
    }

    fun addMultiOrder(client: String, notes: String, items: List<OrderItem>) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            val header = ContentValues().apply { put("client", client); put("notes", notes); put("status", "Pendente") }
            val orderId = db.insertOrThrow("order_headers", null, header)
            items.forEach { item ->
                val values = ContentValues().apply { put("order_id", orderId); put("product", item.product); put("quantity", item.quantity); put("unit_price", item.unitPrice) }
                db.insertOrThrow("order_items", null, values)
            }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }
    fun multiOrders(): List<MultiOrder> {
        val result = mutableListOf<MultiOrder>()
        readableDatabase.rawQuery("SELECT id,client,notes,status FROM order_headers ORDER BY id DESC", null).use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                val items = mutableListOf<OrderItem>()
                readableDatabase.rawQuery("SELECT product,quantity,unit_price FROM order_items WHERE order_id=? ORDER BY id", arrayOf(id.toString())).use { i ->
                    while (i.moveToNext()) items.add(OrderItem(i.getString(0), i.getInt(1), i.getDouble(2)))
                }
                result.add(MultiOrder(id, c.getString(1), c.getString(2), c.getString(3), items))
            }
        }
        return result
    }
    fun deleteMultiOrder(id: Long) {
        writableDatabase.delete("order_items", "order_id=?", arrayOf(id.toString()))
        writableDatabase.delete("order_headers", "id=?", arrayOf(id.toString()))
    }

    fun delete(table: String, id: Long) {
        require(table in listOf("clients", "products", "orders_local"))
        writableDatabase.delete(table, "id=?", arrayOf(id.toString()))
    }
}
