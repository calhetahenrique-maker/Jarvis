# JARVIS Android — Business v0.5.0

Projeto Android Kotlin + Jetpack Compose.

## Business v0.5.0
- Mantém clientes, produtos e encomendas localmente em SQLite.
- Preço de catálogo guardado sem IVA.
- Apresenta preço com IVA à taxa predefinida de 16%.
- Guarda o preço unitário na encomenda para preservar o valor praticado no momento do registo.
- Apresenta totais da encomenda sem IVA e com IVA.
- Migração SQLite da versão 0.4.0 para a versão 0.5.0; os registos existentes são preservados.

## Compilar
Requer JDK 17 e Gradle 8.11.1.

```bash
gradle --no-daemon assembleDebug
```

APK: `app/build/outputs/apk/debug/app-debug.apk`

Nota: esta versão é uma evolução incremental do módulo Business. Ainda não inclui edição avançada de fichas, fotografias de produtos, encomendas com várias linhas, envio Outlook integrado, sincronização ou IA real.
