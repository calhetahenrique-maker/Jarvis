# JARVIS Business v0.9.0

Android app (Kotlin + Jetpack Compose), local SQLite storage.

## v0.9.0
- Edit client records.
- Edit product records and choose a product photo from the device.
- Change order status: Pendente, Enviada, Processada, Entregue.
- Database migration preserves existing records and adds product image URI.

IVA predefinido: 16%.
Warehouse email default: jorge.g.b.pimentel@bensaude.pt.

## Build
Upload `JARVIS-Business-v0.9.0.zip` to the root of the GitHub repository and run the
`Build JARVIS APK` workflow. The workflow creates the `JARVIS-Business-v0.9.0-APK`
artifact. Keep the previously installed version until this workflow succeeds and
the new APK has been installed and checked.

PDF export is not included in this release.
