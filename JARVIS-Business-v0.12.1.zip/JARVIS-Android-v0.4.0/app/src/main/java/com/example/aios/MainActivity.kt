package com.example.aios

import android.os.Bundle
import android.content.Intent
import android.net.Uri
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.ui.graphics.asImageBitmap
import android.graphics.BitmapFactory
import android.graphics.pdf.PdfDocument
import android.graphics.Paint
import android.graphics.Typeface
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF090C12)
private val Panel = Color(0xFF151B26)
private val Panel2 = Color(0xFF202A39)
private val MainText = Color(0xFFF3F5F9)
private val Muted = Color(0xFF9AA6B7)
private val Blue = Color(0xFF91B4FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { JarvisApp(LocalDatabase(this)) }
    }
}
private enum class Page(val label: String) { HOME("Início"), BUSINESS("Business"), AGENTS("Agentes"), CHAT("JARVIS") }
private enum class BizTab(val label: String) { CLIENTS("Clientes"), PRODUCTS("Produtos"), ORDERS("Encomendas") }

@Composable
private fun JarvisApp(db: LocalDatabase) {
    var page by remember { mutableStateOf(Page.HOME) }
    var refresh by remember { mutableIntStateOf(0) }
    MaterialTheme(colorScheme = darkColorScheme(primary = Blue, background = Bg, surface = Panel, onSurface = MainText)) {
        Column(Modifier.fillMaxSize().background(Bg)) {
            Row(Modifier.fillMaxWidth().padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("JARVIS", color = MainText, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Text("PERSONAL • BUSINESS • AI", color = Muted, fontSize = 9.sp, letterSpacing = 1.5.sp)
                }
                Text("LOCAL", color = Muted, fontSize = 10.sp)
            }
            Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 18.dp)) {
                when (page) {
                    Page.HOME -> HomePage(db, { page = it })
                    Page.BUSINESS -> BusinessPage(db) { refresh++ }
                    Page.AGENTS -> AgentsPage()
                    Page.CHAT -> ChatPage()
                }
            }
            NavigationBar(containerColor = Color(0xFF101620)) {
                Page.values().forEach { p ->
                    NavigationBarItem(
                        selected = page == p, onClick = { page = p },
                        icon = { Text(when(p) { Page.HOME -> "⌂"; Page.BUSINESS -> "▦"; Page.AGENTS -> "◎"; Page.CHAT -> "✦" }, color = Blue) },
                        label = { Text(p.label, fontSize = 10.sp) }
                    )
                }
            }
        }
    }
}

@Composable
private fun HomePage(db: LocalDatabase, open: (Page) -> Unit) {
    val clients = db.clients().size
    val products = db.products().size
    val allOrders = db.multiOrders()
    val orders = allOrders.size
    val pending = allOrders.count { it.status == "Pendente" }
    val sales = allOrders.sumOf { order -> order.items.sumOf { it.quantity * it.unitPrice } }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(14.dp), contentPadding = PaddingValues(bottom = 20.dp)) {
        item {
            Text("O teu centro de comando.", color = MainText, fontSize = 27.sp, fontWeight = FontWeight.Bold)
            Text("Tudo o que precisas, num só lugar.", color = Muted)
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatCard("Clientes", clients.toString(), Modifier.weight(1f))
                StatCard("Produtos", products.toString(), Modifier.weight(1f))
                StatCard("Encomendas", orders.toString(), Modifier.weight(1f))
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("RESUMO COMERCIAL", color = Blue, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text("${"%.2f".format(sales)} €", color = MainText, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                    Text("Valor de encomendas sem IVA · $pending pendentes", color = Muted, fontSize = 11.sp)
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("JARVIS ASSISTANT", color = Blue, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text("Bem-vindo ao teu assistente.", color = MainText, fontSize = 21.sp, fontWeight = FontWeight.SemiBold)
                    Text("Os registos de clientes, produtos e encomendas ficam guardados neste dispositivo.", color = Muted, fontSize = 13.sp)
                    Button(onClick = { open(Page.BUSINESS) }) { Text("Abrir Business") }
                }
            }
        }
        item { QuickCard("Agentes inteligentes", "Os teus assistentes especializados") { open(Page.AGENTS) } }
        item { QuickCard("Falar com JARVIS", "Assistente conversacional") { open(Page.CHAT) } }
    }
}

@Composable
private fun StatCard(title: String, value: String, modifier: Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(12.dp)) {
            Text(title, color = Muted, fontSize = 10.sp)
            Text(value, color = MainText, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
    }
}
@Composable
private fun QuickCard(title: String, subtitle: String, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable(onClick = onClick), colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text(title, color = MainText, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
private fun BusinessPage(db: LocalDatabase, changed: () -> Unit) {
    var selected by remember { mutableStateOf(BizTab.CLIENTS) }
    var refresh by remember { mutableIntStateOf(0) }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Business", color = MainText, fontSize = 27.sp, fontWeight = FontWeight.Bold)
        Text("Clientes, catálogo e encomendas • IVA predefinido 16%.", color = Muted, fontSize = 13.sp)
        val context = LocalContext.current
        val backupExport = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
            if (uri != null) runCatching { context.contentResolver.openOutputStream(uri)?.use { it.write(db.exportBackup().toByteArray(Charsets.UTF_8)) } }
        }
        val backupImport = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) runCatching { context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { db.importBackup(it.readText()) }; changed() }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { backupExport.launch("JARVIS-backup-${SimpleDateFormat("yyyyMMdd-HHmm", Locale.getDefault()).format(Date())}.json") }) { Text("Exportar cópia") }
            OutlinedButton(onClick = { backupImport.launch(arrayOf("application/json", "text/*")) }) { Text("Restaurar cópia") }
        }
        Text("Guarda cópias regularmente. Restaurar substitui os registos atuais.", color = Muted, fontSize = 10.sp)
        TabRow(selectedTabIndex = selected.ordinal, containerColor = Bg) {
            BizTab.values().forEach { t -> Tab(selected == t, { selected = t }, text = { Text(t.label, fontSize = 11.sp) }) }
        }
        key(selected, refresh) {
            when (selected) {
                BizTab.CLIENTS -> ClientsTab(db) { refresh++; changed() }
                BizTab.PRODUCTS -> ProductsTab(db) { refresh++; changed() }
                BizTab.ORDERS -> OrdersTab(db) { refresh++; changed() }
            }
        }
    }
}

@Composable
private fun ClientsTab(db: LocalDatabase, changed: () -> Unit) {
    var name by remember { mutableStateOf("") }; var company by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }; var email by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf<Client?>(null) }
    var historyClient by remember { mutableStateOf<Client?>(null) }
    val rows = remember { mutableStateListOf<Client>() }
    LaunchedEffect(Unit) { rows.addAll(db.clients()) }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 20.dp)) {
        item { FormBox("Adicionar cliente") {
            Input(name, { name = it }, "Nome *"); Input(company, { company = it }, "Empresa")
            Input(phone, { phone = it }, "Telefone", KeyboardType.Phone); Input(email, { email = it }, "Email", KeyboardType.Email)
            Button(enabled = name.isNotBlank(), modifier = Modifier.fillMaxWidth(), onClick = {
                db.addClient(name.trim(), company.trim(), phone.trim(), email.trim()); name = ""; company = ""; phone = ""; email = ""
                rows.clear(); rows.addAll(db.clients()); changed()
            }) { Text("Guardar cliente") }
        } }
        item { Text("Clientes registados: ${rows.size} · Toca num cliente para editar", color = Muted, fontSize = 11.sp) }
        items(rows, key = { it.id }) { row ->
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                DataCard(row.name, listOf(row.company, row.phone, row.email).filter { it.isNotBlank() }.joinToString(" • "), onEdit = { editing = row }) {
                    db.delete("clients", row.id); rows.remove(row); changed()
                }
                TextButton(onClick = { historyClient = row }) { Text("Ver histórico de encomendas", fontSize = 11.sp) }
            }
        }
    }
    historyClient?.let { c ->
        val history = db.clientOrders(c.name)
        AlertDialog(onDismissRequest = { historyClient = null }, title = { Text("Histórico · ${c.name}") },
            text = {
                if (history.isEmpty()) Text("Ainda não existem encomendas para este cliente.")
                else Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    history.forEach { order ->
                        val total = order.items.sumOf { it.quantity * it.unitPrice }
                        Text("#${order.id} · ${order.status} · ${"%.2f".format(total * 1.16)} € c/ IVA", color = MainText)
                        Text(order.items.joinToString(", ") { "${it.quantity} × ${it.product}" }, color = Muted, fontSize = 11.sp)
                    }
                }
            },
            confirmButton = { TextButton(onClick = { historyClient = null }) { Text("Fechar") } })
    }
    editing?.let { c ->
        var n by remember(c.id) { mutableStateOf(c.name) }; var co by remember(c.id) { mutableStateOf(c.company) }
        var ph by remember(c.id) { mutableStateOf(c.phone) }; var em by remember(c.id) { mutableStateOf(c.email) }
        AlertDialog(onDismissRequest = { editing = null }, title = { Text("Editar cliente") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(6.dp)) { Input(n,{n=it},"Nome *"); Input(co,{co=it},"Empresa"); Input(ph,{ph=it},"Telefone",KeyboardType.Phone); Input(em,{em=it},"Email",KeyboardType.Email) } },
            confirmButton = { TextButton(enabled=n.isNotBlank(), onClick={ db.updateClient(c.id,n.trim(),co.trim(),ph.trim(),em.trim()); rows.clear(); rows.addAll(db.clients()); editing=null; changed() }) { Text("Guardar") } },
            dismissButton = { TextButton(onClick={editing=null}) { Text("Cancelar") } })
    }
}

@Composable
private fun ProductsTab(db: LocalDatabase, changed: () -> Unit) {
    var name by remember { mutableStateOf("") }; var code by remember { mutableStateOf("") }; var price by remember { mutableStateOf("") }
    var imageUri by remember { mutableStateOf("") }; var editing by remember { mutableStateOf<Product?>(null) }
    val context = LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) { try { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}; imageUri = uri.toString(); editing?.let { editing = it.copy(imageUri = uri.toString()) } }
    }
    val rows = remember { mutableStateListOf<Product>() }
    LaunchedEffect(Unit) { rows.addAll(db.products()) }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 20.dp)) {
        item { FormBox("Adicionar produto") {
            Input(name,{name=it},"Nome do produto *"); Input(code,{code=it},"Referência"); Input(price,{price=it},"Preço (€)",KeyboardType.Decimal)
            OutlinedButton(onClick={picker.launch(arrayOf("image/*"))}, modifier=Modifier.fillMaxWidth()) { Text(if(imageUri.isBlank()) "Escolher fotografia" else "Fotografia selecionada ✓") }
            Button(enabled=name.isNotBlank() && (price.isBlank() || price.replace(",",".").toDoubleOrNull()!=null), modifier=Modifier.fillMaxWidth(), onClick={
                db.addProduct(name.trim(),code.trim(),price.replace(",",".").toDoubleOrNull()?:0.0,imageUri); name=""; code=""; price=""; imageUri=""
                rows.clear(); rows.addAll(db.products()); changed()
            }) { Text("Guardar produto") }
        } }
        item { Text("Produtos registados: ${rows.size} · Toca num produto para editar", color=Muted, fontSize=11.sp) }
        items(rows,key={it.id}) { row ->
            DataCard(row.name, "${row.code} • ${"%.2f".format(row.price)} € + IVA (16%) = ${"%.2f".format(row.price*1.16)} €", onEdit={editing=row}) {
                db.delete("products",row.id); rows.remove(row); changed()
            }
        }
    }
    editing?.let { p ->
        var n by remember(p.id) { mutableStateOf(p.name) }; var co by remember(p.id) { mutableStateOf(p.code) }
        var pr by remember(p.id) { mutableStateOf(p.price.toString()) }
        AlertDialog(onDismissRequest={editing=null}, title={Text("Editar produto")},
            text={Column(verticalArrangement=Arrangement.spacedBy(6.dp)) { Input(n,{n=it},"Nome *"); Input(co,{co=it},"Referência"); Input(pr,{pr=it},"Preço (€)",KeyboardType.Decimal)
                OutlinedButton(onClick={picker.launch(arrayOf("image/*"))},modifier=Modifier.fillMaxWidth()){Text(if(p.imageUri.isBlank())"Escolher fotografia" else "Alterar fotografia")}
                // A imagem escolhida no seletor fica também disponível no formulário de edição.
            }},
            confirmButton={TextButton(enabled=n.isNotBlank() && pr.replace(",",".").toDoubleOrNull()!=null,onClick={db.updateProduct(p.id,n.trim(),co.trim(),pr.replace(",",".").toDouble(),p.imageUri); rows.clear(); rows.addAll(db.products()); editing=null; changed()}){Text("Guardar")}},
            dismissButton={TextButton(onClick={editing=null}){Text("Cancelar")}})
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun OrdersTab(db: LocalDatabase, changed: () -> Unit) {
    var client by remember { mutableStateOf("") }
    var product by remember { mutableStateOf("") }
    var quantity by remember { mutableStateOf("1") }
    var notes by remember { mutableStateOf("") }
    var searchQuery by remember { mutableStateOf("") }
    var clientExpanded by remember { mutableStateOf(false) }
    var productExpanded by remember { mutableStateOf(false) }
    val cart = remember { mutableStateListOf<OrderItem>() }
    val rows = remember { mutableStateListOf<MultiOrder>() }
    val clients = db.clients()
    val products = db.products()
    val context = LocalContext.current
    var pdfOrder by remember { mutableStateOf<MultiOrder?>(null) }
    val pdfLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        val order = pdfOrder
        if (uri != null && order != null) runCatching { context.contentResolver.openOutputStream(uri)?.use { writeOrderPdf(it, order) } }
        pdfOrder = null
    }
    var emailRecipient by remember { mutableStateOf("") }
    var showEmailConfirm by remember { mutableStateOf<MultiOrder?>(null) }
    LaunchedEffect(Unit) { rows.addAll(db.multiOrders()) }
    val subtotal = cart.sumOf { it.quantity * it.unitPrice }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 20.dp)) {
        item {
            FormBox("Nova encomenda · vários artigos") {
                if (clients.isNotEmpty()) {
                    ExposedDropdownMenuBox(expanded = clientExpanded, onExpandedChange = { clientExpanded = it }) {
                        OutlinedTextField(client, {}, readOnly = true, label = { Text("Cliente *") }, modifier = Modifier.fillMaxWidth().menuAnchor())
                        ExposedDropdownMenu(clientExpanded, { clientExpanded = false }) { clients.forEach { c -> DropdownMenuItem(text = { Text(c.name) }, onClick = { client = c.name; clientExpanded = false }) } }
                    }
                } else Text("Adiciona primeiro um cliente.", color = Muted, fontSize = 12.sp)
                if (products.isNotEmpty()) {
                    ExposedDropdownMenuBox(expanded = productExpanded, onExpandedChange = { productExpanded = it }) {
                        OutlinedTextField(product, {}, readOnly = true, label = { Text("Produto") }, modifier = Modifier.fillMaxWidth().menuAnchor())
                        ExposedDropdownMenu(productExpanded, { productExpanded = false }) { products.forEach { p -> DropdownMenuItem(text = { Text("${p.name} · ${"%.2f".format(p.price)} €") }, onClick = { product = p.name; productExpanded = false }) } }
                    }
                } else Text("Adiciona primeiro um produto.", color = Muted, fontSize = 12.sp)
                Input(quantity, { quantity = it.filter(Char::isDigit) }, "Quantidade", KeyboardType.Number)
                Button(enabled = product.isNotBlank() && (quantity.toIntOrNull() ?: 0) > 0, modifier = Modifier.fillMaxWidth(), onClick = {
                    val p = products.firstOrNull { it.name == product }
                    if (p != null) cart.add(OrderItem(p.name, quantity.toInt(), p.price))
                    product = ""; quantity = "1"
                }) { Text("Adicionar artigo à encomenda") }
                if (cart.isNotEmpty()) {
                    Text("Artigos: ${cart.size}", color = Blue, fontWeight = FontWeight.SemiBold)
                    cart.forEachIndexed { index, item ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("${item.quantity} × ${item.product}", color = MainText, fontSize = 13.sp)
                                Text("${"%.2f".format(item.quantity * item.unitPrice)} € s/ IVA", color = Muted, fontSize = 11.sp)
                            }
                            TextButton(onClick = { cart.removeAt(index) }) { Text("Remover") }
                        }
                    }
                    Text("Subtotal: ${"%.2f".format(subtotal)} €", color = MainText)
                    Text("Total com IVA (16%): ${"%.2f".format(subtotal * 1.16)} €", color = Blue, fontWeight = FontWeight.Bold)
                }
                Input(notes, { notes = it }, "Observações")
                Button(enabled = client.isNotBlank() && cart.isNotEmpty(), modifier = Modifier.fillMaxWidth(), onClick = {
                    db.addMultiOrder(client, notes.trim(), cart.toList())
                    client = ""; notes = ""; cart.clear()
                    rows.clear(); rows.addAll(db.multiOrders()); changed()
                }) { Text("Guardar encomenda completa") }
            }
        }
        item { Input(searchQuery, { searchQuery = it }, "Pesquisar por nº, cliente, produto ou observações") }
        val filteredRows = rows.filter { row ->
            val q = searchQuery.trim()
            q.isBlank() || row.id.toString().contains(q, true) || row.client.contains(q, true) ||
                row.notes.contains(q, true) || row.items.any { it.product.contains(q, true) }
        }
        item { Text("Encomendas: ${filteredRows.size} de ${rows.size}", color = Muted, fontSize = 11.sp) }
        items(filteredRows, key = { it.id }) { row ->
            val total = row.items.sumOf { it.quantity * it.unitPrice }
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(13.dp)) {
                Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("#${row.id} · ${row.client}", color = MainText, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    Text(row.items.joinToString("; ") { "${it.quantity} × ${it.product} (${"%.2f".format(it.unitPrice)} €/un.)" } + "\n${"%.2f".format(total)} € s/ IVA · ${"%.2f".format(total * 1.16)} € c/ IVA · ${row.status}" + if (row.notes.isBlank()) "" else "\n${row.notes}", color = Muted, fontSize = 11.sp)
                    var statusMenu by remember(row.id) { mutableStateOf(false) }
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Box {
                            OutlinedButton(onClick = { statusMenu = true }, modifier = Modifier.fillMaxWidth()) { Text("Estado: ${row.status}") }
                            DropdownMenu(expanded = statusMenu, onDismissRequest = { statusMenu = false }) {
                                listOf("Pendente", "Enviada", "Processada", "Entregue").forEach { status ->
                                    DropdownMenuItem(text = { Text(status) }, onClick = { db.updateOrderStatus(row.id,status); rows.clear(); rows.addAll(db.multiOrders()); statusMenu=false; changed() })
                                }
                            }
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { pdfOrder = row; pdfLauncher.launch("JARVIS-Encomenda-${row.id}.pdf") }, modifier = Modifier.weight(1f)) { Text("PDF") }
                            OutlinedButton(onClick = { db.duplicateMultiOrder(row.id); rows.clear(); rows.addAll(db.multiOrders()); changed() }, modifier = Modifier.weight(1f)) { Text("Duplicar") }
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { emailRecipient = ""; showEmailConfirm = row }, modifier = Modifier.weight(1f)) { Text("Enviar ao armazém") }
                            TextButton(onClick = { db.deleteMultiOrder(row.id); rows.remove(row); changed() }, modifier = Modifier.weight(1f)) { Text("Apagar", color = Color(0xFFFF9292)) }
                        }
                    }
                }
            }
        }
    }
    showEmailConfirm?.let { order ->
        AlertDialog(
            onDismissRequest = { showEmailConfirm = null },
            title = { Text("Enviar encomenda #${order.id}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Introduz o endereço de email para esta encomenda. Não fica guardado e poderá ser diferente na próxima.")
                    OutlinedTextField(
                        value = emailRecipient,
                        onValueChange = { emailRecipient = it.trim() },
                        label = { Text("Destinatário (Para) *") },
                        placeholder = { Text("armazem@empresa.pt") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(
                    enabled = android.util.Patterns.EMAIL_ADDRESS.matcher(emailRecipient).matches(),
                    onClick = {
                        val amount = order.items.sumOf { it.quantity * it.unitPrice }
                        val customer = db.clients().firstOrNull { it.name.equals(order.client, ignoreCase = true) }
                        val body = buildString {
                            appendLine("ENCOMENDA JARVIS #${order.id}")
                            appendLine("Cliente: ${order.client}")
                            customer?.company?.takeIf { it.isNotBlank() }?.let { appendLine("Empresa: $it") }
                            customer?.phone?.takeIf { it.isNotBlank() }?.let { appendLine("Telefone: $it") }
                            customer?.email?.takeIf { it.isNotBlank() }?.let { appendLine("Email do cliente: $it") }
                            appendLine()
                            appendLine("ARTIGOS:")
                            order.items.forEach { appendLine("${it.quantity} x ${it.product} | ${"%.2f".format(it.unitPrice)} € / unidade | ${"%.2f".format(it.quantity * it.unitPrice)} €") }
                            appendLine()
                            appendLine("Subtotal sem IVA: ${"%.2f".format(amount)} €")
                            appendLine("IVA (16%): ${"%.2f".format(amount * 0.16)} €")
                            appendLine("Total com IVA: ${"%.2f".format(amount * 1.16)} €")
                            if (order.notes.isNotBlank()) { appendLine(); appendLine("Observações: ${order.notes}") }
                        }
                        try {
                            val pdfFile = File(context.cacheDir, "JARVIS-Encomenda-${order.id}.pdf")
                            pdfFile.outputStream().use { writeOrderPdf(it, order) }
                            val pdfUri = FileProvider.getUriForFile(context, "${context.packageName}.provider", pdfFile)
                            val intent = Intent(Intent.ACTION_SEND).apply {
                                type = "application/pdf"
                                putExtra(Intent.EXTRA_EMAIL, arrayOf(emailRecipient))
                                putExtra(Intent.EXTRA_SUBJECT, "Encomenda JARVIS #${order.id} - ${order.client}")
                                putExtra(Intent.EXTRA_TEXT, body)
                                putExtra(Intent.EXTRA_STREAM, pdfUri)
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            context.startActivity(Intent.createChooser(intent, "Enviar encomenda com…"))
                        } catch (_: Exception) {
                            android.widget.Toast.makeText(context, "Não foi possível abrir uma aplicação de email.", android.widget.Toast.LENGTH_LONG).show()
                        }
                        showEmailConfirm = null
                    }
                ) { Text("Abrir email") }
            },
            dismissButton = { TextButton(onClick = { showEmailConfirm = null }) { Text("Cancelar") } }
        )
    }
}

private fun writeOrderPdf(output: java.io.OutputStream, order: MultiOrder) {
    val pdf = PdfDocument()
    val pageWidth = 595
    val pageHeight = 842
    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 11f; color = android.graphics.Color.rgb(35, 43, 56) }
    val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 22f; typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD); color = android.graphics.Color.rgb(25, 48, 82) }
    val boldPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 12f; typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD); color = android.graphics.Color.rgb(25, 48, 82) }
    var pageNo = 1
    var page = pdf.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNo).create())
    var canvas = page.canvas
    var y = 58f
    fun line(text: String, p: Paint = paint, gap: Float = 21f) {
        if (y > pageHeight - 65) { pdf.finishPage(page); pageNo++; page = pdf.startPage(PdfDocument.PageInfo.Builder(pageWidth,pageHeight,pageNo).create()); canvas=page.canvas; y=55f }
        canvas.drawText(text.take(90), 48f, y, p); y += gap
    }
    canvas.drawColor(android.graphics.Color.WHITE)
    line("JARVIS BUSINESS", boldPaint, 30f)
    line("ENCOMENDA #${order.id}", titlePaint, 36f)
    line("Data: ${SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date())}")
    line("Cliente: ${order.client}", boldPaint)
    if (order.notes.isNotBlank()) line("Observações: ${order.notes}")
    y += 12f
    line("ARTIGOS", boldPaint)
    line("Descrição | Qtd. | Preço un. | Total", boldPaint)
    order.items.forEach { item -> line("${item.product} | ${item.quantity} | ${"%.2f".format(item.unitPrice)} € | ${"%.2f".format(item.quantity * item.unitPrice)} €") }
    val subtotal = order.items.sumOf { it.quantity * it.unitPrice }
    y += 15f
    line("Subtotal sem IVA: ${"%.2f".format(subtotal)} €", boldPaint)
    line("IVA (16%): ${"%.2f".format(subtotal * 0.16)} €")
    line("TOTAL COM IVA: ${"%.2f".format(subtotal * 1.16)} €", titlePaint, 30f)
    line("Estado: ${order.status}")
    line("Documento gerado pela aplicação JARVIS Business.", paint, 16f)
    pdf.finishPage(page)
    pdf.writeTo(output)
    pdf.close()
}

@Composable
private fun FormBox(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, color = MainText, fontWeight = FontWeight.SemiBold)
            content()
        }
    }
}
@Composable
private fun Input(value: String, onChange: (String) -> Unit, label: String, type: KeyboardType = KeyboardType.Text) {
    OutlinedTextField(value, onChange, label = { Text(label) }, modifier = Modifier.fillMaxWidth(),
        singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = type))
}
@Composable
private fun DataCard(title: String, subtitle: String, onEdit: (() -> Unit)? = null, delete: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(13.dp)) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, color = MainText, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Text(subtitle.ifBlank { "Sem detalhes" }, color = Muted, fontSize = 11.sp)
            }
            if (onEdit != null) TextButton(onClick = onEdit) { Text("Editar", fontSize = 11.sp) }
            TextButton(onClick = delete) { Text("Apagar", color = Color(0xFFFF9292), fontSize = 11.sp) }
        }
    }
}
@Composable
private fun AgentsPage() {
    val agents = listOf(
        "JARVIS Master" to "Coordena os pedidos.",
        "Business Agent" to "Clientes, vendas e encomendas.",
        "Finance Agent" to "Receitas e despesas.",
        "Planner Agent" to "Agenda e tarefas.",
        "Project Agent" to "Projetos e objetivos.",
        "Documents Agent" to "Notas e documentos.",
        "Automation Agent" to "Automatizações com confirmação."
    )
    LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp)) {
        item { Text("Agentes", color = MainText, fontSize = 27.sp, fontWeight = FontWeight.Bold); Text("Assistentes especializados — integração IA numa próxima fase.", color = Muted, fontSize = 12.sp) }
        items(agents) { (name, desc) -> Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(Modifier.padding(15.dp)) { Text(name, color = MainText, fontWeight = FontWeight.SemiBold); Text(desc, color = Muted, fontSize = 12.sp); Text("Planeado", color = Blue, fontSize = 10.sp) }
        } }
    }
}
@Composable
private fun ChatPage() {
    var prompt by remember { mutableStateOf("") }
    var chat by remember { mutableStateOf(listOf("JARVIS: Olá! A ligação a um modelo de IA gratuito será configurada numa próxima fase.")) }
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Assistente JARVIS", color = MainText, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(chat) { Card(colors = CardDefaults.cardColors(containerColor = Panel)) { Text(it, Modifier.padding(13.dp), color = MainText, fontSize = 13.sp) } }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(7.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(prompt, { prompt = it }, modifier = Modifier.weight(1f), placeholder = { Text("Escreve uma mensagem") }, singleLine = true)
            Button(onClick = { if (prompt.isNotBlank()) { chat = chat + "Tu: $prompt" + "JARVIS: Ainda não estou ligado a um modelo de IA."; prompt = "" } }) { Text("Enviar") }
        }
    }
}
