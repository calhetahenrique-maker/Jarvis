package com.example.aios

import android.os.Bundle
import android.content.Intent
import android.net.Uri
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.ui.graphics.asImageBitmap
import android.graphics.BitmapFactory
import android.graphics.pdf.PdfDocument
import android.graphics.Paint
import android.graphics.Typeface
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFFF6F8FC)
private val Panel = Color(0xFFFFFFFF)
private val Panel2 = Color(0xFFEEF3FA)
private val MainText = Color(0xFF172338)
private val Muted = Color(0xFF77849A)
private val Blue = Color(0xFF2869D8)
private val BlueSoft = Color(0xFFEAF2FF)
private val Teal = Color(0xFF20A7A0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { JarvisApp(LocalDatabase(this)) }
    }
}
private enum class Page(val label: String) { HOME("Início"), BUSINESS("Business"), AGENTS("Agentes"), CHAT("JARVIS") }
private enum class BizTab(val label: String) { CLIENTS("Clientes"), PRODUCTS("Produtos"), ORDERS("Encomendas"), COMMERCIAL("Comercial") }

@Composable
private fun JarvisApp(db: LocalDatabase) {
    var page by remember { mutableStateOf(Page.HOME) }
    var refresh by remember { mutableIntStateOf(0) }
    MaterialTheme(colorScheme = lightColorScheme(
        primary = Blue, onPrimary = Color.White, secondary = Teal,
        background = Bg, onBackground = MainText, surface = Panel,
        onSurface = MainText, surfaceVariant = Panel2,
        onSurfaceVariant = Muted, outline = Color(0xFFE1E7F0)
    )) {
        Column(Modifier.fillMaxSize().background(Bg)) {
            Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 17.dp, bottom = 13.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(42.dp).background(Blue, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                    Text("J", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Black)
                }
                Spacer(Modifier.width(11.dp))
                Column(Modifier.weight(1f)) {
                    Text("JARVIS", color = MainText, fontSize = 21.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.1.sp)
                    Text("PERSONAL  /  BUSINESS  /  AI", color = Muted, fontSize = 8.sp, letterSpacing = 1.25.sp)
                }
                Surface(color = Color(0xFFEAF7F4), shape = RoundedCornerShape(50)) {
                    Row(Modifier.padding(horizontal = 11.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(6.dp).background(Teal, RoundedCornerShape(50)))
                        Spacer(Modifier.width(6.dp)); Text("LOCAL", color = Color(0xFF16877F), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
            Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 16.dp)) {
                when (page) {
                    Page.HOME -> HomePage(db, { page = it })
                    Page.BUSINESS -> BusinessPage(db) { refresh++ }
                    Page.AGENTS -> AgentsPage()
                    Page.CHAT -> ChatPage()
                }
            }
            NavigationBar(containerColor = Color.White, contentColor = MainText, tonalElevation = 8.dp) {
                Page.values().forEach { p ->
                    NavigationBarItem(
                        selected = page == p, onClick = { page = p },
                        icon = { Text(when(p) { Page.HOME -> "⌂"; Page.BUSINESS -> "▦"; Page.AGENTS -> "◎"; Page.CHAT -> "✧" }, color = if (page == p) Blue else Muted, fontSize = 21.sp) },
                        label = { Text(p.label, fontSize = 10.sp, fontWeight = if (page == p) FontWeight.Bold else FontWeight.Normal) },
                        colors = NavigationBarItemDefaults.colors(selectedIconColor = Blue, selectedTextColor = Blue, indicatorColor = BlueSoft)
                    )
                }
            }
        }
    }
}

@Composable
private fun HomePage(db: LocalDatabase, open: (Page) -> Unit) {
    val clients = db.clients().size
    val products = db.products().size
    val allOrders = db.multiOrders()
    val orders = allOrders.size
    val pending = allOrders.count { it.status == "Pendente" }
    val sales = allOrders.sumOf { order -> order.items.sumOf { it.quantity * it.unitPrice } }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(15.dp), contentPadding = PaddingValues(top = 7.dp, bottom = 24.dp)) {
        item {
            Text("O teu centro de comando", color = MainText, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-0.5).sp)
            Text("Bom trabalho. Aqui está o estado do teu negócio.", color = Muted, fontSize = 13.sp)
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Blue), shape = RoundedCornerShape(25.dp), elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)) {
                Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(color = Color.White.copy(alpha = 0.16f), shape = RoundedCornerShape(9.dp)) { Text("✦  JARVIS INTELLIGENCE", Modifier.padding(horizontal = 10.dp, vertical = 6.dp), color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp) }
                        Spacer(Modifier.weight(1f)); Text("● ONLINE", color = Color(0xFFC8F8EE), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                    Text("Tudo sob controlo.", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Text("Acompanha clientes, encomendas e atividade comercial num só lugar.", color = Color.White.copy(alpha = 0.82f), fontSize = 12.sp)
                    Button(onClick = { open(Page.BUSINESS) }, colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Blue), shape = RoundedCornerShape(12.dp)) { Text("Abrir Business  →", fontWeight = FontWeight.Bold) }
                }
            }
        }
        item { Text("VISÃO GERAL", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("Clientes", clients.toString(), "♙", Modifier.weight(1f))
                StatCard("Produtos", products.toString(), "◇", Modifier.weight(1f))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("Encomendas", orders.toString(), "▤", Modifier.weight(1f))
                StatCard("Pendentes", pending.toString(), "◷", Modifier.weight(1f))
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(21.dp), elevation = CardDefaults.cardElevation(1.dp)) {
                Column(Modifier.fillMaxWidth().padding(17.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) { Text("RESUMO COMERCIAL", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp); Spacer(Modifier.weight(1f)); Text("↗", color = Teal, fontSize = 18.sp) }
                    Text("${"%.2f".format(sales)} €", color = MainText, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold)
                    Text("Valor de encomendas sem IVA", color = Muted, fontSize = 11.sp)
                }
            }
        }
        item { Text("ACESSO RÁPIDO", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                QuickCard("Business", "Clientes e vendas", "▦", Modifier.weight(1f)) { open(Page.BUSINESS) }
                QuickCard("Agentes", "Assistentes", "◎", Modifier.weight(1f)) { open(Page.AGENTS) }
            }
        }
        item { QuickCard("Falar com JARVIS", "Assistente conversacional", "✧", Modifier.fillMaxWidth()) { open(Page.CHAT) } }
    }
}

@Composable
private fun StatCard(title: String, value: String, symbol: String, modifier: Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp), elevation = CardDefaults.cardElevation(1.dp)) {
        Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Box(Modifier.size(31.dp).background(BlueSoft, RoundedCornerShape(10.dp)), contentAlignment = Alignment.Center) { Text(symbol, color = Blue, fontSize = 17.sp) }
            Text(value, color = MainText, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
            Text(title, color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Medium)
        }
    }
}
@Composable
private fun QuickCard(title: String, subtitle: String, symbol: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Card(modifier.clickable(onClick = onClick), colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(19.dp), elevation = CardDefaults.cardElevation(1.dp)) {
        Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(39.dp).background(BlueSoft, RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) { Text(symbol, color = Blue, fontSize = 20.sp) }
            Spacer(Modifier.width(11.dp))
            Column(Modifier.weight(1f)) { Text(title, color = MainText, fontWeight = FontWeight.Bold, fontSize = 13.sp); Text(subtitle, color = Muted, fontSize = 10.sp) }
            Text("›", color = Blue, fontSize = 23.sp, fontWeight = FontWeight.Light)
        }
    }
}

@Composable
private fun BusinessPage(db: LocalDatabase, changed: () -> Unit) {
    var selected by remember { mutableStateOf(BizTab.CLIENTS) }
    var refresh by remember { mutableIntStateOf(0) }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Business", color = MainText, fontSize = 27.sp, fontWeight = FontWeight.Bold)
        Text("Clientes, catálogo e encomendas • IVA predefinido 16%.", color = Muted, fontSize = 13.sp)
        val context = LocalContext.current
        val backupExport = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
            if (uri != null) runCatching { context.contentResolver.openOutputStream(uri)?.use { it.write(db.exportBackup().toByteArray(Charsets.UTF_8)) } }
        }
        var showRestoreConfirm by remember { mutableStateOf(false) }
        var backupMessage by remember { mutableStateOf("") }
        val backupImport = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                val result = runCatching {
                    context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { db.importBackup(it.readText()) }
                        ?: error("Não foi possível abrir o ficheiro selecionado.")
                }
                if (result.isSuccess) { backupMessage = "Cópia restaurada com sucesso."; changed() }
                else backupMessage = "Não foi possível restaurar: ${result.exceptionOrNull()?.localizedMessage ?: "ficheiro inválido"}"
                android.widget.Toast.makeText(context, backupMessage, android.widget.Toast.LENGTH_LONG).show()
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { backupExport.launch("JARVIS-backup-${SimpleDateFormat("yyyyMMdd-HHmm", Locale.getDefault()).format(Date())}.json") }) { Text("Criar / exportar cópia") }
            OutlinedButton(onClick = { showRestoreConfirm = true }) { Text("Restaurar cópia") }
        }
        Text("Escolhe onde guardar: no telemóvel ou num serviço cloud (Google Drive, OneDrive, etc.). A restauração substitui os registos atuais.", color = Muted, fontSize = 10.sp)
        if (showRestoreConfirm) {
            AlertDialog(
                onDismissRequest = { showRestoreConfirm = false },
                title = { Text("Restaurar cópia de segurança?") },
                text = { Text("Os dados atuais de clientes, produtos, encomendas e atividade comercial serão substituídos pelos dados da cópia selecionada. Esta ação não pode ser desfeita. Queres continuar?") },
                confirmButton = {
                    TextButton(onClick = { showRestoreConfirm = false; backupImport.launch(arrayOf("application/json", "text/*")) }) { Text("Continuar") }
                },
                dismissButton = { TextButton(onClick = { showRestoreConfirm = false }) { Text("Cancelar") }
                }
            )
        }
        TabRow(selectedTabIndex = selected.ordinal, containerColor = Bg, contentColor = Blue) {
            BizTab.values().forEach { t -> Tab(selected == t, { selected = t }, text = { Text(t.label, fontSize = 11.sp) }) }
        }
        key(selected, refresh) {
            when (selected) {
                BizTab.CLIENTS -> ClientsTab(db) { refresh++; changed() }
                BizTab.PRODUCTS -> ProductsTab(db) { refresh++; changed() }
                BizTab.ORDERS -> OrdersTab(db) { refresh++; changed() }
                BizTab.COMMERCIAL -> CommercialTab(db) { refresh++; changed() }
            }
        }
    }
}

@Composable
private fun ClientsTab(db: LocalDatabase, changed: () -> Unit) {
    var name by remember { mutableStateOf("") }; var company by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }; var email by remember { mutableStateOf("") }; var clientNumber by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf<Client?>(null) }
    var historyClient by remember { mutableStateOf<Client?>(null) }
    val rows = remember { mutableStateListOf<Client>() }
    LaunchedEffect(Unit) { rows.addAll(db.clients()) }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 20.dp)) {
        item { FormBox("Adicionar cliente") {
            Input(name, { name = it }, "Nome *"); Input(company, { company = it }, "Empresa")
            Input(phone, { phone = it }, "Telefone", KeyboardType.Phone); Input(email, { email = it }, "Email", KeyboardType.Email)
            Input(clientNumber, { clientNumber = it }, "N.º de cliente")
            Button(enabled = name.isNotBlank(), modifier = Modifier.fillMaxWidth(), onClick = {
                db.addClient(name.trim(), company.trim(), phone.trim(), email.trim(), clientNumber.trim()); name = ""; company = ""; phone = ""; email = ""; clientNumber = ""
                rows.clear(); rows.addAll(db.clients()); changed()
            }) { Text("Guardar cliente") }
        } }
        item { Text("Clientes registados: ${rows.size} · Toca num cliente para editar", color = Muted, fontSize = 11.sp) }
        items(rows, key = { it.id }) { row ->
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                DataCard(row.name, listOf(if (row.number.isNotBlank()) "N.º ${row.number}" else "", row.company, row.phone, row.email).filter { it.isNotBlank() }.joinToString(" • "), onEdit = { editing = row }) {
                    db.delete("clients", row.id); rows.remove(row); changed()
                }
                TextButton(onClick = { historyClient = row }) { Text("Ver histórico de encomendas", fontSize = 11.sp) }
            }
        }
    }
    historyClient?.let { c ->
        val history = db.clientOrders(c.name)
        AlertDialog(onDismissRequest = { historyClient = null }, title = { Text("Histórico · ${c.name}") },
            text = {
                if (history.isEmpty()) Text("Ainda não existem encomendas para este cliente.")
                else Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    history.forEach { order ->
                        val total = order.items.sumOf { it.quantity * it.unitPrice }
                        Text("#${order.id} · ${order.status} · ${"%.2f".format(total * 1.16)} € c/ IVA", color = MainText)
                        Text(order.items.joinToString(", ") { "${it.quantity} × ${it.product}" }, color = Muted, fontSize = 11.sp)
                    }
                }
            },
            confirmButton = { TextButton(onClick = { historyClient = null }) { Text("Fechar") } })
    }
    editing?.let { c ->
        var n by remember(c.id) { mutableStateOf(c.name) }; var co by remember(c.id) { mutableStateOf(c.company) }
        var ph by remember(c.id) { mutableStateOf(c.phone) }; var em by remember(c.id) { mutableStateOf(c.email) }; var cn by remember(c.id) { mutableStateOf(c.number) }
        AlertDialog(onDismissRequest = { editing = null }, title = { Text("Editar cliente") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(6.dp)) { Input(n,{n=it},"Nome *"); Input(co,{co=it},"Empresa"); Input(ph,{ph=it},"Telefone",KeyboardType.Phone); Input(em,{em=it},"Email",KeyboardType.Email); Input(cn,{cn=it},"N.º de cliente") } },
            confirmButton = { TextButton(enabled=n.isNotBlank(), onClick={ db.updateClient(c.id,n.trim(),co.trim(),ph.trim(),em.trim(),cn.trim()); rows.clear(); rows.addAll(db.clients()); editing=null; changed() }) { Text("Guardar") } },
            dismissButton = { TextButton(onClick={editing=null}) { Text("Cancelar") } })
    }
}

@Composable
private fun ProductsTab(db: LocalDatabase, changed: () -> Unit) {
    var name by remember { mutableStateOf("") }; var code by remember { mutableStateOf("") }; var price by remember { mutableStateOf("") }
    var imageUri by remember { mutableStateOf("") }; var editing by remember { mutableStateOf<Product?>(null) }
    val context = LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) { try { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}; imageUri = uri.toString(); editing?.let { editing = it.copy(imageUri = uri.toString()) } }
    }
    val rows = remember { mutableStateListOf<Product>() }
    LaunchedEffect(Unit) { rows.addAll(db.products()) }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 20.dp)) {
        item { FormBox("Adicionar produto") {
            Input(name,{name=it},"Nome do produto *"); Input(code,{code=it},"Referência"); Input(price,{price=it},"Preço (€)",KeyboardType.Decimal)
            OutlinedButton(onClick={picker.launch(arrayOf("image/*"))}, modifier=Modifier.fillMaxWidth()) { Text(if(imageUri.isBlank()) "Escolher fotografia" else "Fotografia selecionada ✓") }
            Button(enabled=name.isNotBlank() && (price.isBlank() || price.replace(",",".").toDoubleOrNull()!=null), modifier=Modifier.fillMaxWidth(), onClick={
                db.addProduct(name.trim(),code.trim(),price.replace(",",".").toDoubleOrNull()?:0.0,imageUri); name=""; code=""; price=""; imageUri=""
                rows.clear(); rows.addAll(db.products()); changed()
            }) { Text("Guardar produto") }
        } }
        item { Text("Produtos registados: ${rows.size} · Toca num produto para editar", color=Muted, fontSize=11.sp) }
        items(rows,key={it.id}) { row ->
            DataCard(row.name, "${row.code} • ${"%.2f".format(row.price)} € + IVA (16%) = ${"%.2f".format(row.price*1.16)} €", onEdit={editing=row}) {
                db.delete("products",row.id); rows.remove(row); changed()
            }
        }
    }
    editing?.let { p ->
        var n by remember(p.id) { mutableStateOf(p.name) }; var co by remember(p.id) { mutableStateOf(p.code) }
        var pr by remember(p.id) { mutableStateOf(p.price.toString()) }
        AlertDialog(onDismissRequest={editing=null}, title={Text("Editar produto")},
            text={Column(verticalArrangement=Arrangement.spacedBy(6.dp)) { Input(n,{n=it},"Nome *"); Input(co,{co=it},"Referência"); Input(pr,{pr=it},"Preço (€)",KeyboardType.Decimal)
                OutlinedButton(onClick={picker.launch(arrayOf("image/*"))},modifier=Modifier.fillMaxWidth()){Text(if(p.imageUri.isBlank())"Escolher fotografia" else "Alterar fotografia")}
                // A imagem escolhida no seletor fica também disponível no formulário de edição.
            }},
            confirmButton={TextButton(enabled=n.isNotBlank() && pr.replace(",",".").toDoubleOrNull()!=null,onClick={db.updateProduct(p.id,n.trim(),co.trim(),pr.replace(",",".").toDouble(),p.imageUri); rows.clear(); rows.addAll(db.products()); editing=null; changed()}){Text("Guardar")}},
            dismissButton={TextButton(onClick={editing=null}){Text("Cancelar")}})
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun OrdersTab(db: LocalDatabase, changed: () -> Unit) {
    var client by remember { mutableStateOf("") }
    var product by remember { mutableStateOf("") }
    var quantity by remember { mutableStateOf("1") }
    var notes by remember { mutableStateOf("") }
    var searchQuery by remember { mutableStateOf("") }
    var clientExpanded by remember { mutableStateOf(false) }
    var productExpanded by remember { mutableStateOf(false) }
    val cart = remember { mutableStateListOf<OrderItem>() }
    val rows = remember { mutableStateListOf<MultiOrder>() }
    val clients = db.clients()
    val products = db.products()
    val context = LocalContext.current
    var pdfOrder by remember { mutableStateOf<MultiOrder?>(null) }
    val pdfLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        val order = pdfOrder
        if (uri != null && order != null) runCatching { context.contentResolver.openOutputStream(uri)?.use { writeOrderPdf(context, db, it, order) } }
        pdfOrder = null
    }
    var emailRecipient by remember { mutableStateOf("") }
    var showEmailConfirm by remember { mutableStateOf<MultiOrder?>(null) }
    LaunchedEffect(Unit) { rows.addAll(db.multiOrders()) }
    val subtotal = cart.sumOf { it.quantity * it.unitPrice }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 20.dp)) {
        item {
            FormBox("Nova encomenda · vários artigos") {
                if (clients.isNotEmpty()) {
                    ExposedDropdownMenuBox(expanded = clientExpanded, onExpandedChange = { clientExpanded = it }) {
                        OutlinedTextField(client, {}, readOnly = true, label = { Text("Cliente *") }, modifier = Modifier.fillMaxWidth().menuAnchor())
                        ExposedDropdownMenu(clientExpanded, { clientExpanded = false }) { clients.forEach { c -> DropdownMenuItem(text = { Text(c.name) }, onClick = { client = c.name; clientExpanded = false }) } }
                    }
                } else Text("Adiciona primeiro um cliente.", color = Muted, fontSize = 12.sp)
                if (products.isNotEmpty()) {
                    ExposedDropdownMenuBox(expanded = productExpanded, onExpandedChange = { productExpanded = it }) {
                        OutlinedTextField(product, {}, readOnly = true, label = { Text("Produto") }, modifier = Modifier.fillMaxWidth().menuAnchor())
                        ExposedDropdownMenu(productExpanded, { productExpanded = false }) { products.forEach { p -> DropdownMenuItem(text = { Text("${p.name} · ${"%.2f".format(p.price)} €") }, onClick = { product = p.name; productExpanded = false }) } }
                    }
                } else Text("Adiciona primeiro um produto.", color = Muted, fontSize = 12.sp)
                Input(quantity, { quantity = it.filter(Char::isDigit) }, "Quantidade", KeyboardType.Number)
                Button(enabled = product.isNotBlank() && (quantity.toIntOrNull() ?: 0) > 0, modifier = Modifier.fillMaxWidth(), onClick = {
                    val p = products.firstOrNull { it.name == product }
                    if (p != null) cart.add(OrderItem(p.name, quantity.toInt(), p.price))
                    product = ""; quantity = "1"
                }) { Text("Adicionar artigo à encomenda") }
                if (cart.isNotEmpty()) {
                    Text("Artigos: ${cart.size}", color = Blue, fontWeight = FontWeight.SemiBold)
                    cart.forEachIndexed { index, item ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("${item.quantity} × ${item.product}", color = MainText, fontSize = 13.sp)
                                Text("${"%.2f".format(item.quantity * item.unitPrice)} € s/ IVA", color = Muted, fontSize = 11.sp)
                            }
                            TextButton(onClick = { cart.removeAt(index) }) { Text("Remover") }
                        }
                    }
                    Text("Subtotal: ${"%.2f".format(subtotal)} €", color = MainText)
                    Text("Total com IVA (16%): ${"%.2f".format(subtotal * 1.16)} €", color = Blue, fontWeight = FontWeight.Bold)
                }
                Input(notes, { notes = it }, "Observações")
                Button(enabled = client.isNotBlank() && cart.isNotEmpty(), modifier = Modifier.fillMaxWidth(), onClick = {
                    db.addMultiOrder(client, notes.trim(), cart.toList())
                    client = ""; notes = ""; cart.clear()
                    rows.clear(); rows.addAll(db.multiOrders()); changed()
                }) { Text("Guardar encomenda completa") }
            }
        }
        item { Input(searchQuery, { searchQuery = it }, "Pesquisar por nº, cliente, produto ou observações") }
        val filteredRows = rows.filter { row ->
            val q = searchQuery.trim()
            q.isBlank() || row.id.toString().contains(q, true) || row.client.contains(q, true) ||
                row.notes.contains(q, true) || row.items.any { it.product.contains(q, true) }
        }
        item { Text("Encomendas: ${filteredRows.size} de ${rows.size}", color = Muted, fontSize = 11.sp) }
        items(filteredRows, key = { it.id }) { row ->
            val total = row.items.sumOf { it.quantity * it.unitPrice }
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(13.dp)) {
                Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("#${row.id} · ${row.client}", color = MainText, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    Text(row.items.joinToString("; ") { "${it.quantity} × ${it.product} (${"%.2f".format(it.unitPrice)} €/un.)" } + "\n${"%.2f".format(total)} € s/ IVA · ${"%.2f".format(total * 1.16)} € c/ IVA · ${row.status}" + if (row.notes.isBlank()) "" else "\n${row.notes}", color = Muted, fontSize = 11.sp)
                    var statusMenu by remember(row.id) { mutableStateOf(false) }
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Box {
                            OutlinedButton(onClick = { statusMenu = true }, modifier = Modifier.fillMaxWidth()) { Text("Estado: ${row.status}") }
                            DropdownMenu(expanded = statusMenu, onDismissRequest = { statusMenu = false }) {
                                listOf("Pendente", "Enviada", "Processada", "Entregue").forEach { status ->
                                    DropdownMenuItem(text = { Text(status) }, onClick = { db.updateOrderStatus(row.id,status); rows.clear(); rows.addAll(db.multiOrders()); statusMenu=false; changed() })
                                }
                            }
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { pdfOrder = row; pdfLauncher.launch("JARVIS-Encomenda-${row.id}.pdf") }, modifier = Modifier.weight(1f)) { Text("PDF") }
                            OutlinedButton(onClick = { db.duplicateMultiOrder(row.id); rows.clear(); rows.addAll(db.multiOrders()); changed() }, modifier = Modifier.weight(1f)) { Text("Duplicar") }
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { emailRecipient = ""; showEmailConfirm = row }, modifier = Modifier.weight(1f)) { Text("Enviar ao armazém") }
                            TextButton(onClick = { db.deleteMultiOrder(row.id); rows.remove(row); changed() }, modifier = Modifier.weight(1f)) { Text("Apagar", color = Color(0xFFFF9292)) }
                        }
                    }
                }
            }
        }
    }
    showEmailConfirm?.let { order ->
        AlertDialog(
            onDismissRequest = { showEmailConfirm = null },
            title = { Text("Enviar encomenda #${order.id}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Introduz o endereço de email para esta encomenda. Não fica guardado e poderá ser diferente na próxima.")
                    OutlinedTextField(
                        value = emailRecipient,
                        onValueChange = { emailRecipient = it.trim() },
                        label = { Text("Destinatário (Para) *") },
                        placeholder = { Text("armazem@empresa.pt") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(
                    enabled = android.util.Patterns.EMAIL_ADDRESS.matcher(emailRecipient).matches(),
                    onClick = {
                        val amount = order.items.sumOf { it.quantity * it.unitPrice }
                        val customer = db.clients().firstOrNull { it.name.equals(order.client, ignoreCase = true) }
                        val body = buildString {
                            appendLine("ENCOMENDA JARVIS #${order.id}")
                            appendLine("Cliente: ${order.client}")
                            customer?.number?.takeIf { it.isNotBlank() }?.let { appendLine("N.º de cliente: $it") }
                            customer?.company?.takeIf { it.isNotBlank() }?.let { appendLine("Empresa: $it") }
                            customer?.phone?.takeIf { it.isNotBlank() }?.let { appendLine("Telefone: $it") }
                            customer?.email?.takeIf { it.isNotBlank() }?.let { appendLine("Email do cliente: $it") }
                            appendLine()
                            appendLine("ARTIGOS:")
                            order.items.forEach { appendLine("${it.quantity} x ${it.product} | ${"%.2f".format(it.unitPrice)} € / unidade | ${"%.2f".format(it.quantity * it.unitPrice)} €") }
                            appendLine()
                            appendLine("Subtotal sem IVA: ${"%.2f".format(amount)} €")
                            appendLine("IVA (16%): ${"%.2f".format(amount * 0.16)} €")
                            appendLine("Total com IVA: ${"%.2f".format(amount * 1.16)} €")
                            if (order.notes.isNotBlank()) { appendLine(); appendLine("Observações: ${order.notes}") }
                        }
                        try {
                            val pdfFile = File(context.cacheDir, "JARVIS-Encomenda-${order.id}.pdf")
                            pdfFile.outputStream().use { writeOrderPdf(context, db, it, order) }
                            val pdfUri = FileProvider.getUriForFile(context, "${context.packageName}.provider", pdfFile)
                            val intent = Intent(Intent.ACTION_SEND).apply {
                                type = "application/pdf"
                                putExtra(Intent.EXTRA_EMAIL, arrayOf(emailRecipient))
                                putExtra(Intent.EXTRA_SUBJECT, "Encomenda JARVIS #${order.id} - ${order.client}")
                                putExtra(Intent.EXTRA_TEXT, body)
                                putExtra(Intent.EXTRA_STREAM, pdfUri)
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            context.startActivity(Intent.createChooser(intent, "Enviar encomenda com…"))
                        } catch (_: Exception) {
                            android.widget.Toast.makeText(context, "Não foi possível abrir uma aplicação de email.", android.widget.Toast.LENGTH_LONG).show()
                        }
                        showEmailConfirm = null
                    }
                ) { Text("Abrir email") }
            },
            dismissButton = { TextButton(onClick = { showEmailConfirm = null }) { Text("Cancelar") } }
        )
    }
}

private fun writeOrderPdf(context: android.content.Context, db: LocalDatabase, output: java.io.OutputStream, order: MultiOrder) {
    val pdf = PdfDocument()
    val pageWidth = 595
    val pageHeight = 842
    val navy = android.graphics.Color.rgb(22, 45, 75)
    val blue = android.graphics.Color.rgb(35, 100, 160)
    val ink = android.graphics.Color.rgb(38, 47, 58)
    val muted = android.graphics.Color.rgb(100, 110, 122)
    val border = android.graphics.Color.rgb(220, 226, 233)
    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 10f; color = ink }
    val small = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 8f; color = muted }
    val bold = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 10f; typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD); color = navy }
    val title = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 21f; typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD); color = navy }
    val white = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.WHITE }
    var pageNo = 1
    var page = pdf.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNo).create())
    var canvas = page.canvas
    var y = 42f
    canvas.drawColor(android.graphics.Color.WHITE)
    canvas.drawRect(0f, 0f, pageWidth.toFloat(), 12f, Paint().apply { color = blue })
    fun startPage() {
        pageNo++
        page = pdf.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNo).create())
        canvas = page.canvas
        canvas.drawColor(android.graphics.Color.WHITE)
        canvas.drawRect(0f, 0f, pageWidth.toFloat(), 12f, Paint().apply { color = blue })
        y = 42f
    }
    fun finishPage() { pdf.finishPage(page) }
    fun text(value: String, x: Float, baseline: Float, p: Paint = paint) { canvas.drawText(value, x, baseline, p) }
    fun headerContinuation() { text("ENCOMENDA #${order.id} · continuação", 38f, 35f, bold); y = 55f }
    fun ensure(height: Float) { if (y + height > pageHeight - 45) { finishPage(); startPage(); headerContinuation() } }
    text("JARVIS BUSINESS", 38f, y, bold); y += 30f
    text("GUIA DE ENCOMENDA", 38f, y, title); y += 28f
    text("N.º ${order.id}", 38f, y, bold)
    text("Data: ${SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date())}", 330f, y, paint); y += 27f
    val customer = db.clients().firstOrNull { it.name.equals(order.client, ignoreCase = true) }
    canvas.drawRoundRect(34f, y - 15f, 560f, y + 58f, 8f, 8f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.rgb(244,247,250) })
    text("CLIENTE", 46f, y + 2f, small)
    text(order.client.take(48), 46f, y + 20f, bold)
    text("N.º cliente: ${customer?.number?.takeIf { it.isNotBlank() } ?: "—"}", 330f, y + 2f, bold)
    text((customer?.company ?: "").take(38), 330f, y + 20f, paint)
    text("Contacto: ${customer?.phone?.takeIf { it.isNotBlank() } ?: "—"}", 46f, y + 40f, small)
    text("Email: ${customer?.email?.takeIf { it.isNotBlank() } ?: "—"}".take(48), 330f, y + 40f, small)
    y += 82f
    text("ARTIGOS A PREPARAR", 38f, y, bold); y += 18f
    fun drawHeader() {
        canvas.drawRect(34f, y - 12f, 561f, y + 8f, Paint().apply { color = navy })
        text("FOTO", 42f, y + 2f, white); text("CÓDIGO / DESCRIÇÃO", 100f, y + 2f, white)
        text("QTD.", 360f, y + 2f, white); text("PREÇO", 405f, y + 2f, white); text("TOTAL", 485f, y + 2f, white)
        y += 25f
    }
    drawHeader()
    order.items.forEach { item ->
        ensure(78f)
        val product = db.products().firstOrNull { it.name.equals(item.product, ignoreCase = true) }
        val top = y - 13f
        canvas.drawRoundRect(36f, top, 88f, top + 54f, 4f, 4f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.rgb(246,248,250); style = Paint.Style.FILL })
        if (product?.imageUri?.isNotBlank() == true) {
            runCatching {
                context.contentResolver.openInputStream(android.net.Uri.parse(product.imageUri))?.use { android.graphics.BitmapFactory.decodeStream(it) }
            }.getOrNull()?.let { bitmap ->
                val src = android.graphics.Rect(0, 0, bitmap.width, bitmap.height)
                val dst = android.graphics.RectF(38f, top + 2f, 86f, top + 52f)
                canvas.drawBitmap(bitmap, src, dst, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
                bitmap.recycle()
            }
        }
        text((product?.code?.takeIf { it.isNotBlank() } ?: "Sem código").take(32), 100f, y, bold)
        text(item.product.take(39), 100f, y + 17f, paint)
        text(item.quantity.toString(), 365f, y + 8f, bold)
        text("%.2f €".format(item.unitPrice), 405f, y + 8f, paint)
        text("%.2f €".format(item.quantity * item.unitPrice), 485f, y + 8f, bold)
        canvas.drawLine(36f, y + 42f, 558f, y + 42f, Paint().apply { color = border; strokeWidth = 0.8f })
        y += 65f
    }
    val subtotal = order.items.sumOf { it.quantity * it.unitPrice }
    ensure(115f)
    y += 8f
    text("Subtotal sem IVA", 350f, y, paint); text("%.2f €".format(subtotal), 485f, y, bold); y += 18f
    text("IVA (16%)", 350f, y, paint); text("%.2f €".format(subtotal * 0.16), 485f, y, paint); y += 23f
    text("TOTAL COM IVA", 350f, y, bold); text("%.2f €".format(subtotal * 1.16), 475f, y, title); y += 30f
    text("Estado: ${order.status}", 38f, y, small); y += 18f
    if (order.notes.isNotBlank()) {
        ensure(55f); text("OBSERVAÇÕES", 38f, y, bold); y += 16f
        order.notes.chunked(82).forEach { line -> ensure(18f); text(line, 38f, y, paint); y += 15f }
    }
    text("Documento gerado pela aplicação JARVIS Business", 38f, 815f, small)
    finishPage()
    pdf.writeTo(output)
    pdf.close()
}

@Composable
private fun FormBox(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp), elevation = CardDefaults.cardElevation(1.dp)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, color = MainText, fontWeight = FontWeight.SemiBold)
            content()
        }
    }
}
@Composable
private fun Input(value: String, onChange: (String) -> Unit, label: String, type: KeyboardType = KeyboardType.Text) {
    OutlinedTextField(value, onChange, label = { Text(label) }, modifier = Modifier.fillMaxWidth(),
        singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = type))
}
@Composable
private fun DataCard(title: String, subtitle: String, onEdit: (() -> Unit)? = null, delete: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(17.dp), elevation = CardDefaults.cardElevation(1.dp)) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, color = MainText, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Text(subtitle.ifBlank { "Sem detalhes" }, color = Muted, fontSize = 11.sp)
            }
            if (onEdit != null) TextButton(onClick = onEdit) { Text("Editar", fontSize = 11.sp) }
            TextButton(onClick = delete) { Text("Apagar", color = Color(0xFFFF9292), fontSize = 11.sp) }
        }
    }
}
@Composable
private fun AgentsPage() {
    val agents = listOf(
        "JARVIS Master" to "Coordena os pedidos.",
        "Business Agent" to "Clientes, vendas e encomendas.",
        "Finance Agent" to "Receitas e despesas.",
        "Planner Agent" to "Agenda e tarefas.",
        "Project Agent" to "Projetos e objetivos.",
        "Documents Agent" to "Notas e documentos.",
        "Automation Agent" to "Automatizações com confirmação."
    )
    LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp)) {
        item { Text("Agentes", color = MainText, fontSize = 27.sp, fontWeight = FontWeight.Bold); Text("Assistentes especializados — integração IA numa próxima fase.", color = Muted, fontSize = 12.sp) }
        items(agents) { (name, desc) -> Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(Modifier.padding(15.dp)) { Text(name, color = MainText, fontWeight = FontWeight.SemiBold); Text(desc, color = Muted, fontSize = 12.sp); Text("Planeado", color = Blue, fontSize = 10.sp) }
        } }
    }
}
@Composable
private fun ChatPage() {
    var prompt by remember { mutableStateOf("") }
    var chat by remember { mutableStateOf(listOf("JARVIS: Olá! A ligação a um modelo de IA gratuito será configurada numa próxima fase.")) }
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Assistente JARVIS", color = MainText, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(chat) { Card(colors = CardDefaults.cardColors(containerColor = Panel)) { Text(it, Modifier.padding(13.dp), color = MainText, fontSize = 13.sp) } }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(7.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(prompt, { prompt = it }, modifier = Modifier.weight(1f), placeholder = { Text("Escreve uma mensagem") }, singleLine = true)
            Button(onClick = { if (prompt.isNotBlank()) { chat = chat + "Tu: $prompt" + "JARVIS: Ainda não estou ligado a um modelo de IA."; prompt = "" } }) { Text("Enviar") }
        }
    }
}


@Composable
@OptIn(ExperimentalMaterial3Api::class)
private fun CommercialTab(db: LocalDatabase, changed: () -> Unit) {
    val context = LocalContext.current
    var client by remember { mutableStateOf("") }
    var type by remember { mutableStateOf("Visita") }
    var date by remember { mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())) }
    var subject by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var validUntil by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Pendente") }
    var followUp by remember { mutableStateOf("") }
    var expanded by remember { mutableStateOf(false) }
    val clients = db.clients()
    val rows = remember { mutableStateListOf<Array<String>>() }
    fun reload() { rows.clear(); rows.addAll(db.commercialActivities()) }
    LaunchedEffect(Unit) { reload() }

    val csvLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        if (uri != null) runCatching {
            val header = "ID;Cliente;Tipo;Data;Assunto;Notas;Resultado;Valor;Validade;Estado;Próximo acompanhamento"
            fun q(v: String) = "\"" + v.replace("\"", "\"\"") + "\""
            val body = (listOf(header) + rows.map { it.joinToString(";") { v -> q(v) } }).joinToString("\r\n")
            context.contentResolver.openOutputStream(uri)?.use { it.write(("\uFEFF" + body).toByteArray(Charsets.UTF_8)) }
        }
    }
    val pdfLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null) runCatching {
            val pdf = PdfDocument()
            val paint = Paint().apply { textSize = 10f; color = android.graphics.Color.BLACK }
            val titlePaint = Paint().apply { textSize = 18f; typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD); color = android.graphics.Color.BLACK }
            var pageNo = 1
            var page = pdf.startPage(PdfDocument.PageInfo.Builder(595, 842, pageNo).create())
            var y = 48f
            page.canvas.drawText("JARVIS · RELATÓRIO COMERCIAL", 40f, y, titlePaint); y += 28f
            page.canvas.drawText("Gerado em ${SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date())}", 40f, y, paint); y += 24f
            rows.forEach { r ->
                val line = "#${r[0]} | ${r[1]} | ${r[2]} | ${r[3]} | ${r[4]} | ${r[9]}"
                if (y > 800f) { pdf.finishPage(page); pageNo++; page = pdf.startPage(PdfDocument.PageInfo.Builder(595, 842, pageNo).create()); y = 48f }
                page.canvas.drawText(line.take(105), 40f, y, paint); y += 16f
                listOf(r[5], r[6], "Valor: ${r[7]} € · Próximo: ${r[10]}").filter { it.isNotBlank() }.forEach { t ->
                    if (y > 800f) { pdf.finishPage(page); pageNo++; page = pdf.startPage(PdfDocument.PageInfo.Builder(595, 842, pageNo).create()); y = 48f }
                    page.canvas.drawText(t.take(105), 52f, y, paint); y += 14f
                }
                y += 8f
            }
            pdf.finishPage(page)
            context.contentResolver.openOutputStream(uri)?.use { pdf.writeTo(it) }
            pdf.close()
        }
    }

    LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            FormBox("Registar atividade comercial") {
                ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
                    OutlinedTextField(type, { }, readOnly = true, label = { Text("Tipo de atividade") }, modifier = Modifier.menuAnchor().fillMaxWidth())
                    ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        listOf("Visita", "Chamada", "Email", "Reunião", "Proposta", "Orçamento", "Oportunidade").forEach { option ->
                            DropdownMenuItem(text = { Text(option) }, onClick = { type = option; expanded = false })
                        }
                    }
                }
                var clientExpanded by remember { mutableStateOf(false) }
                ExposedDropdownMenuBox(expanded = clientExpanded, onExpandedChange = { clientExpanded = !clientExpanded }) {
                    OutlinedTextField(client, { client = it }, label = { Text("Cliente *") }, modifier = Modifier.menuAnchor().fillMaxWidth())
                    ExposedDropdownMenu(expanded = clientExpanded, onDismissRequest = { clientExpanded = false }) {
                        clients.forEach { c -> DropdownMenuItem(text = { Text(c.name) }, onClick = { client = c.name; clientExpanded = false }) }
                    }
                }
                Input(date, { date = it }, "Data (AAAA-MM-DD)")
                Input(subject, { subject = it }, "Assunto")
                Input(notes, { notes = it }, "Notas")
                Input(result, { result = it }, "Resultado")
                Input(amount, { amount = it }, "Valor (€)", KeyboardType.Decimal)
                Input(validUntil, { validUntil = it }, "Validade (AAAA-MM-DD)")
                Input(status, { status = it }, "Estado")
                Input(followUp, { followUp = it }, "Próximo acompanhamento (AAAA-MM-DD)")
                Button(enabled = client.isNotBlank() && date.isNotBlank(), modifier = Modifier.fillMaxWidth(), onClick = {
                    val selected = clients.firstOrNull { it.name.equals(client, true) }
                    db.addCommercialActivity(selected?.id ?: 0L, client.trim(), type, date.trim(), subject.trim(), notes.trim(), result.trim(),
                        amount.replace(",", ".").toDoubleOrNull() ?: 0.0, validUntil.trim(), status.trim(), followUp.trim())
                    client = ""; subject = ""; notes = ""; result = ""; amount = ""; validUntil = ""; followUp = ""
                    reload(); changed()
                }) { Text("Guardar atividade") }
            }
        }
        item {
            Text("RELATÓRIOS COMERCIAIS", color = Blue, fontWeight = FontWeight.Bold)
            Text("Exporta toda a atividade registada em PDF ou CSV compatível com Excel.", color = Muted, fontSize = 11.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { pdfLauncher.launch("JARVIS-relatorio-comercial.pdf") }) { Text("Exportar PDF") }
                OutlinedButton(onClick = { csvLauncher.launch("JARVIS-relatorio-comercial.csv") }) { Text("Exportar Excel") }
            }
        }
        item { Text("Atividades registadas: ${rows.size}", color = Muted, fontSize = 12.sp) }
        items(rows.size) { index ->
            val r = rows[index]
            DataCard("${r[2]} · ${r[1]}", listOf(r[3], r[4], r[9], if (r[7].isNotBlank()) "${r[7]} €" else "", if (r[10].isNotBlank()) "Acompanhar: ${r[10]}" else "").filter { it.isNotBlank() }.joinToString(" • "), onEdit = {}) {
                // Registos comerciais são mantidos no histórico para auditoria.
            }
        }
    }
}
