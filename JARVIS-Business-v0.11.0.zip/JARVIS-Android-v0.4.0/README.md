# JARVIS Business v0.11.0

Aplicação Android Kotlin + Jetpack Compose, com base de dados SQLite local.

## Novidades v0.11.0
- Pesquisa de encomendas por número, cliente, produto ou observações.
- Histórico de encomendas por cliente.
- Duplicar uma encomenda existente (cria uma nova encomenda pendente).
- Painel comercial com valor das encomendas sem IVA e quantidade pendente.
- Envio de encomenda por email com PDF anexado (o utilizador revê e confirma o envio).
- Mantém geração/guarda de PDF e cópias de segurança JSON introduzidas na v0.10.0.

IVA predefinido: 16%.
Email de armazém predefinido: jorge.g.b.pimentel@bensaude.pt.
Application ID: com.example.aios.

## Compilar no GitHub Actions
1. Colocar `JARVIS-Business-v0.11.0.zip` na raiz do repositório.
2. Executar o workflow `Build JARVIS APK`.
3. Descarregar o artefacto `JARVIS-Business-v0.11.0-APK`.

## Importante sobre atualizações
A aplicação tem o mesmo applicationId e versionCode superior. Para instalar como atualização sem desinstalar, a chave de assinatura usada no APK deve ser a mesma da versão instalada. Se o Android indicar conflito de assinatura, não desinstalar a app: é necessário compilar com a mesma chave de assinatura original.

A compilação não foi validada localmente nesta entrega. Confirmar o resultado do GitHub Actions antes de instalar.
