package com.example.aios

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class Client(val id: Long, val name: String, val company: String, val phone: String, val email: String)
data class Product(val id: Long, val name: String, val code: String, val price: Double)
data class OrderRow(val id: Long, val client: String, val product: String, val quantity: Int, val notes: String, val unitPrice: Double, val status: String)

class LocalDatabase(context: Context) : SQLiteOpenHelper(context, "jarvis_local.db", null, 2) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE clients (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, company TEXT NOT NULL DEFAULT '', phone TEXT NOT NULL DEFAULT '', email TEXT NOT NULL DEFAULT '')")
        db.execSQL("CREATE TABLE products (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, code TEXT NOT NULL DEFAULT '', price REAL NOT NULL DEFAULT 0)")
        db.execSQL("CREATE TABLE orders_local (id INTEGER PRIMARY KEY AUTOINCREMENT, client TEXT NOT NULL, product TEXT NOT NULL, quantity INTEGER NOT NULL, notes TEXT NOT NULL DEFAULT '', unit_price REAL NOT NULL DEFAULT 0, status TEXT NOT NULL DEFAULT 'Pendente')")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE orders_local ADD COLUMN unit_price REAL NOT NULL DEFAULT 0")
            db.execSQL("ALTER TABLE orders_local ADD COLUMN status TEXT NOT NULL DEFAULT 'Pendente'")
        }
    }

    fun addClient(name: String, company: String, phone: String, email: String) {
        writableDatabase.insert("clients", null, ContentValues().apply {
            put("name", name); put("company", company); put("phone", phone); put("email", email)
        })
    }
    fun addProduct(name: String, code: String, price: Double) {
        writableDatabase.insert("products", null, ContentValues().apply {
            put("name", name); put("code", code); put("price", price)
        })
    }
    fun addOrder(client: String, product: String, quantity: Int, notes: String, unitPrice: Double) {
        writableDatabase.insert("orders_local", null, ContentValues().apply {
            put("client", client); put("product", product); put("quantity", quantity); put("notes", notes); put("unit_price", unitPrice); put("status", "Pendente")
        })
    }
    fun clients(): List<Client> = readableDatabase.rawQuery("SELECT id,name,company,phone,email FROM clients ORDER BY name", null).use { c ->
        buildList { while (c.moveToNext()) add(Client(c.getLong(0), c.getString(1), c.getString(2), c.getString(3), c.getString(4))) }
    }
    fun products(): List<Product> = readableDatabase.rawQuery("SELECT id,name,code,price FROM products ORDER BY name", null).use { c ->
        buildList { while (c.moveToNext()) add(Product(c.getLong(0), c.getString(1), c.getString(2), c.getDouble(3))) }
    }
    fun orders(): List<OrderRow> = readableDatabase.rawQuery("SELECT id,client,product,quantity,notes,unit_price,status FROM orders_local ORDER BY id DESC", null).use { c ->
        buildList { while (c.moveToNext()) add(OrderRow(c.getLong(0), c.getString(1), c.getString(2), c.getInt(3), c.getString(4), c.getDouble(5), c.getString(6))) }
    }
    fun delete(table: String, id: Long) {
        require(table in listOf("clients", "products", "orders_local"))
        writableDatabase.delete(table, "id=?", arrayOf(id.toString()))
    }
}
